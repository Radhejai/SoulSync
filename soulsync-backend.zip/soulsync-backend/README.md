# SoulSync Backend — v0.1 (Auth Foundation)

Phase 1 of the phased build: secure signup, mobile OTP verification, login,
and a protected `/users/me` endpoint. Everything else (communities, posts,
reports, local sub-groups) builds on top of this foundation in later phases.

## Stack
- **NestJS (TypeScript)** — structured, testable, enforces good patterns
- **Supabase (Postgres)** — free tier, Row-Level Security enabled on every table
- **JWT** (access + refresh tokens) for sessions
- **bcrypt** for password hashing (12 rounds)
- **helmet + throttler + class-validator** for hardening

## Setup (zero-cost)

1. **Create a free Supabase project** at supabase.com
2. In Supabase → SQL Editor, run `supabase/schema.sql` to create tables + RLS policies
3. Copy `.env.example` to `.env` and fill in:
   - `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` (Supabase → Settings → API)
   - `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` — generate with:
     ```
     node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
     ```
     (run twice, once per secret — never reuse the same value)
4. Install and run:
   ```
   npm install
   npm run start:dev
   ```
5. Test signup:
   ```
   curl -X POST http://localhost:3000/auth/signup \
     -H "Content-Type: application/json" \
     -d '{"email":"you@example.com","mobileNumber":"+919876543210","password":"MyPass123!"}'
   ```
   Check your terminal logs for the OTP (stub provider — no real SMS is sent yet).
6. Verify OTP:
   ```
   curl -X POST http://localhost:3000/auth/verify-otp \
     -H "Content-Type: application/json" \
     -d '{"mobileNumber":"+919876543210","code":"123456","purpose":"signup"}'
   ```
   Returns an `accessToken` + `refreshToken`.
7. Call the protected route:
   ```
   curl http://localhost:3000/users/me -H "Authorization: Bearer <accessToken>"
   ```

## Security decisions baked in (so you don't have to remember why)
- **RLS on every table** — even if app code has a bug, the DB itself blocks unauthorized access
- **Service role key never leaves the backend** — used only in `config/supabase.provider.ts`
- **OTP codes are hashed (SHA-256), never stored raw**, expire in 10 min, capped at 5 attempts, and are single-use
- **Passwords hashed with bcrypt (12 rounds)** — never stored or logged in plaintext
- **Generic error messages** on login/signup so attackers can't tell which accounts exist
- **Global rate limiting** (20 req/min default) + tighter limits on OTP verify (5/min) and login (10/min)
- **Strict input validation** — unknown/extra fields in requests are rejected outright
- **CORS locked** to your configured frontend origin only — not `*`

## What's stubbed for now (zero cost, wire in later)
- **OTP delivery** — currently logs the code to your server console instead of sending a real SMS. See `src/auth/otp.service.ts` → swap `StubOtpProvider` for a real one (MSG91 is cheap and India-friendly; Twilio has free trial credits) when you're ready. No other file needs to change.
- **Email verification** — schema has `email_verified` but no flow wired yet; same pattern as mobile OTP, add when ready.
- **Profile picture capture + liveness check** — comes with the "tiered identity verification" phase.

## Next phases (not built yet)
- Communities module (create/join, category browsing, 88-member local auto-split logic)
- Posts/comments feed per community
- Report queue + severity escalation (3-strike review, anonymous reporter identity)
- Inactivity job (150/175/180-day warnings + archive, 1-year hard delete)
- Payments module

Tell me which phase to build next.
