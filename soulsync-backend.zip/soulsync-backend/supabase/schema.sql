-- Run this in Supabase SQL Editor to set up the initial schema.
-- RLS is enabled on every table: even if application code has a bug,
-- Postgres itself blocks unauthorized reads/writes.

create extension if not exists "pgcrypto";

-- ============ USERS ============
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  mobile_number text unique not null,
  password_hash text not null,
  email_verified boolean not null default false,
  mobile_verified boolean not null default false,
  verification_tier text not null default 'unverified'
    check (verification_tier in ('unverified','basic','verified','trusted')),
  profile_picture_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table users enable row level security;

-- The backend uses the SERVICE ROLE key, which bypasses RLS by design —
-- these policies protect against any future direct client-side access
-- (e.g. if you later expose Supabase's anon key to the frontend).
create policy "Users can read own row"
  on users for select
  using (auth.uid() = id);

create policy "Users can update own row"
  on users for update
  using (auth.uid() = id);

-- No insert/delete policy for regular clients — only the backend
-- (service role) can create or remove accounts.

-- ============ OTP REQUESTS ============
-- Never exposed to any client role — service role only, by omission of policy.
create table if not exists otp_requests (
  mobile_number text not null,
  purpose text not null check (purpose in ('signup','login','reset_password')),
  code_hash text not null,
  attempts int not null default 0,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  primary key (mobile_number, purpose)
);

alter table otp_requests enable row level security;
-- Intentionally no policies: default-deny for all non-service-role access.

-- ============ COMMUNITIES (phase 2 groundwork) ============
create table if not exists communities (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  description text,
  category text not null,
  creator_id uuid references users(id),
  member_count int not null default 0,
  is_archived boolean not null default false,
  last_activity_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table communities enable row level security;

create policy "Anyone can view non-archived communities"
  on communities for select
  using (is_archived = false);

-- Insert/update restricted to service role (enforced in application logic,
-- since community creation involves business rules beyond a simple owner check).

create index if not exists idx_communities_category on communities(category);
create index if not exists idx_communities_last_activity on communities(last_activity_at);
